﻿namespace W2G.EF
{
    public interface IReferenceEntity
    {
        string Reference { get; set; }
    }
}
